package com.pujari.demopractice.Service;

//import jakarta.transaction.Transactional;
//import lombok.AllArgsConstructor;
//import org.springframework.stereotype.Service;
//
//@Service
//@Transactional
//@AllArgsConstructor
public class EmployeeService {


}
