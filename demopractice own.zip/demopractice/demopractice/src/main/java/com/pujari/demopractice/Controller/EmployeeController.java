package com.pujari.demopractice.Controller;

import com.pujari.demopractice.Dto.EmployeeDTO;
import com.pujari.demopractice.Entity.Employee;
import com.pujari.demopractice.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/v1/employees")
public class EmployeeController {
//    @Autowired
//    private EmployeeService employeeService;

    //public ResponseEntity<Employee> addEmployee(EmployeeDTO employeeDTO) {

       // return new ResponseEntity<>(employeeService.addEmployee

}
