package com.pujari.demopractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemopracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
